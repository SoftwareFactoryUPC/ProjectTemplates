## Francisco Rivera - franr.com.ar/hex |
## ------------------------------------/

# import os
import random
from threading import Thread
import pygame
import sys
from random import randint 
from copy import deepcopy
import constantes 
# constantes
RUN = True
LONG = 30
ROJO = (255, 4, 4)
ROJO_C = (255, 80, 80)
ROJO_C_SALTO = (255, 160, 160)
AZUL = (0, 127, 245)
AZUL_C = (50, 177, 255)
AZUL_C_SALTO = (100, 200, 255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
color_jugador_claro = ROJO_C
jugador = ROJO
piedra_a = pygame.image.load("imagen_1_a.png")
papel_a = pygame.image.load("imagen_2_a.png")
tijera_a = pygame.image.load("imagen_3_a.png")
piedra_r = pygame.image.load("imagen_1_r.png")
papel_r = pygame.image.load("imagen_2_r.png")
tijera_r = pygame.image.load("imagen_3_r.png")
estado_vacio = 0
estado_pi_r = 1
estado_pa_r = 2
estado_ti_r = 3
estado_pi_a = 4
estado_pa_a = 5
estado_ti_a = 6
num_pi_r = 1
num_pa_r = 1
num_ti_r = 1
num_pi_a = 1
num_pa_a = 1
num_ti_a = 1
lista_marc = [] 
estado_ficha_s = 0 
ficha_s = None
MAQUINA = False
DIFICULTAD = 0

def iniciar():
    global color_jugador_claro 
    global jugador 
    global estado_vacio 
    global estado_pi_r 
    global estado_pa_r 
    global estado_ti_r 
    global estado_pi_a 
    global estado_pa_a 
    global estado_ti_a 
    global num_pi_r 
    global num_pa_r 
    global num_ti_r 
    global num_pi_a 
    global num_pa_a 
    global num_ti_a 
    global lista_marc 
    global estado_ficha_s 
    global ficha_s 
    color_jugador_claro = ROJO_C
    jugador = ROJO
    estado_vacio = 0
    estado_pi_r = 1
    estado_pa_r = 2
    estado_ti_r = 3
    estado_pi_a = 4
    estado_pa_a = 5
    estado_ti_a = 6
    num_pi_r = 1
    num_pa_r = 1
    num_ti_r = 1
    num_pi_a = 1
    num_pa_a = 1
    num_ti_a = 1
    lista_marc = [] 
    estado_ficha_s = 0 
    ficha_s = None

def encerrado(hexas):
    for fila in hexas:
        for key, hexa in fila.iteritems(): 
            if jugador == ROJO:
                if hexa.estado in [4,5,6]:
                    for ind in hexa.lista_adya+hexa.lista_salto:
                        if existe(ind,hexas):
                            if hexas[ind[0]][ind[1]].estado == 0:
                                return False
            else:
                if hexa.estado in [1,2,3]:
                    for ind in hexa.lista_adya+hexa.lista_salto:
                        if existe(ind,hexas):
                            if hexas[ind[0]][ind[1]].estado == 0:
                                return False
                

    return True

def aumentar_marcador(estado):
    global num_pi_r 
    global num_pa_r 
    global num_ti_r 
    global num_pi_a 
    global num_pa_a 
    global num_ti_a 
    if estado==2:
        num_pa_r+=1
    if estado==4:
        num_pi_a+=1
    if estado==6:
        num_ti_a+=1
    if estado==3:
        num_ti_r+=1
    if estado==1:
        num_pi_r+=1
    if estado==5:
        num_pa_a+=1

def dibujar_marcador(pantalla):
    fuente = Fuente()

    pantalla.blit(piedra_r,(700,200))
    pantalla.blit(fuente.render(str(num_pi_r)),(750,200))
    pantalla.blit(piedra_a,(900,200))
    pantalla.blit(fuente.render(str(num_pi_a)),(950,200))
    pantalla.blit(papel_r,(700,300))
    pantalla.blit(fuente.render(str(num_pa_r)),(750,300))
    pantalla.blit(papel_a,(900,300))
    pantalla.blit(fuente.render(str(num_pa_a)),(950,300))
    pantalla.blit(tijera_r,(700,400))
    pantalla.blit(fuente.render(str(num_ti_r)),(750,400))
    pantalla.blit(tijera_a,(900,400))
    pantalla.blit(fuente.render(str(num_ti_a)),(950,400))

    pygame.draw.line(pantalla,BLANCO,(650,450),(800,450),3)
    pantalla.blit(fuente.render(str(num_ti_r+num_pa_r+num_pi_r)),(750,500))
    pygame.draw.line(pantalla,BLANCO,(850,450),(1000,450),3)
    pantalla.blit(fuente.render(str(num_ti_a+num_pa_a+num_pi_a)),(950,500))

def cambiar_jugador(hexas):
    global jugador
    global color_jugador_claro
    
    if jugador == AZUL:
        jugador = ROJO
        color_jugador_claro = ROJO_C
    else:
        jugador = AZUL
        color_jugador_claro = AZUL_C
    limpiar(hexas)

def limpiar(hexas):   
    for lista in hexas:
        for he in lista: 
            lista[he].marcada = False 
            lista[he].color = BLANCO 
            lista[he].dibujar()

def existe(ind,hexas):
    existe = False 
    if ind[0]>-1 and ind[0]<9:
        if ind[1]>-1 and ind[1]<len(hexas[ind[0]]):
            existe=True
    return existe

def atacar(hexa,hexas,pantalla):
    global num_pi_r 
    global num_pa_r 
    global num_ti_r 
    global num_pi_a 
    global num_pa_a 
    global num_ti_a 
    for adya in hexa.lista_adya:
        if existe(adya,hexas):
            if hexa.estado == 1:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==6:
                    hexa_adya.estado=1
                    num_pi_r+=1
                    num_ti_a-=1
            if hexa.estado == 2:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==4:
                    hexa_adya.estado=2
                    num_pa_r+=1
                    num_pi_a-=1
            if hexa.estado == 3:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==5:
                    hexa_adya.estado=3
                    num_ti_r+=1
                    num_pa_a-=1
            if hexa.estado == 4:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==3:
                    hexa_adya.estado=4
                    num_pi_a+=1
                    num_ti_r-=1
            if hexa.estado == 5:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==1:
                    hexa_adya.estado=5
                    num_pa_a+=1
                    num_pi_r-=1
            if hexa.estado == 6:
                hexa_adya = hexas[adya[0]][adya[1]]
                if hexa_adya.estado==2:
                    hexa_adya.estado=6
                    num_ti_a+=1
                    num_pa_r-=1
    if  encerrado(hexas):
        #pan=Pantalla()
        #pan.color = jugador
        #pan.ganador()
        #import pdb 
        #pdb.set_trace()
        return True
    return False      

def atacar_experto(destino,matriz_f):
    hexa = matriz_f[destino[0]][destino[1]]
    for adya in hexa.lista_adya:
        if existe(adya,matriz_f):
            if hexa.estado == 1:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==6:
                    hexa_adya.estado=1
                    
            if hexa.estado == 2:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==4:
                    hexa_adya.estado=2
                    
            if hexa.estado == 3:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==5:
                    hexa_adya.estado=3
                    
            if hexa.estado == 4:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==3:
                    hexa_adya.estado=4
                    
            if hexa.estado == 5:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==1:
                    hexa_adya.estado=5
                    
            if hexa.estado == 6:
                hexa_adya = matriz_f[adya[0]][adya[1]]
                if hexa_adya.estado==2:
                    hexa_adya.estado=6
                    
    if  encerrado(matriz_f):
        return True
    return False      
    
def ubicacion(hexa,hexas):
    for fila in hexas:
        for key, h in fila.iteritems(): 
            if h == hexa:
                return (hexas.index(fila),key)

def jugar_maquina(hexas,pantalla):

    global num_pi_a 
    global num_pa_a 
    global num_ti_a 

    ficha = randint(4,6)
    while 1:
        if ficha==4 and num_pi_a>0:
            break
        if ficha==5 and num_pa_a>0:
            break
        if ficha==6 and num_ti_a>0:
            break
        ficha = randint(4,6)
        
    jugada = randint(0,1)
    lugar_ind = (-1,-1)
    for fila in hexas:
        for key, hexa in fila.iteritems():
            if hexa.estado==ficha:
                existir = False
                while not existir:
                    if jugada==0: #CLONACION
                        lugar = randint(0,5)
                        lugar_ind = hexa.lista_adya[lugar]

                    else: # SALTO 
                        lugar = randint(0,7)
                        lugar_ind = hexa.lista_salto[lugar] 
                        hexa.estado = 0
                    existir = existe(lugar_ind,hexas)
                    if existir:
                        hexa_nueva = hexas[lugar_ind[0]][lugar_ind[1]]
                        if hexa_nueva.estado != 0:
                            existir=False 
                
                hexa_nueva.estado = ficha   
                atacar(hexa_nueva,hexas,pantalla)
                
                if jugada == 0:
                    aumentar_marcador(hexa_nueva.estado)
                
                hexa_nueva.dibujar()
                #import pdb
                #pdb.set_trace()
                return False

    if encerrado(hexas):
        return True
    return False
            
def maximo_valor(hexa,hexas):
    mayor=0 
    hex_destino = (-1,-1)
    salto = False
    

    for destino in hexa.lista_adya:
        if existe(destino,hexas):
            hexa_destino = hexas[destino[0]][destino[1]]
            if hexa_destino.estado == 0:
                origen = ubicacion(hexa,hexas) 
                f_evaluadora = valor_funcion(hexas,origen, destino,False)
                if f_evaluadora>mayor:

                    mayor = f_evaluadora
                    hex_destino = destino

    for destino in hexa.lista_salto:
        if existe(destino,hexas):
            hexa_destino = hexas[destino[0]][destino[1]]
            if hexa_destino.estado == 0:
                origen = ubicacion(hexa,hexas) 
                

                f_evaluadora = valor_funcion(hexas,origen, destino,True)
                if f_evaluadora>mayor:
                    salto=True
                    mayor = f_evaluadora
                    hex_destino = destino
            
    return {'valor':mayor,'destino':hex_destino ,'salto':salto}

def maximo_humano(matriz_f):
    mejor_casilla = None    
    cant_mejor = -1   
    mayor = 0
    for fila in matriz_f:
        for key, hexa in fila.iteritems():
            if hexa.estado in [1,2,3]:
                maximo_ficha= maximo_valor(hexa,matriz_f)
                mayor = maximo_ficha['valor']
                if mayor > cant_mejor: 
                    cant_mejor = mayor 
                    mejor_casilla = maximo_ficha

    return mejor_casilla


def maximo_valor_experto(hexa,hexas):
    menor=100 
    hex_destino = (-1,-1)
    salto = False
    matriz_f = []
    
    for destino in hexa.lista_adya:
        if existe(destino,hexas):
            hexa_destino = hexas[destino[0]][destino[1]]
            if hexa_destino.estado == 0:
                origen = ubicacion(hexa,hexas) 

                matriz_f = deepcopy(hexas)
                
                estado = hexa.estado
                matriz_f[destino[0]][destino[1]].estado = estado
                atacar_experto(destino,matriz_f)
                f_evaluadora = -1*valor_funcion(hexas,origen, destino,False)
                maximo_h = maximo_humano(matriz_f)
                if maximo_h != None:
                    maxi = maximo_h['valor']
                else:
                    maxi = 0

                diferencia = maxi + f_evaluadora
                if diferencia<menor:
                    menor=diferencia
                    
                    hex_destino = destino
                      

    for destino in hexa.lista_salto:
        if existe(destino,hexas):
            hexa_destino = hexas[destino[0]][destino[1]]
            if hexa_destino.estado == 0:
                origen = ubicacion(hexa,hexas) 
                matriz_f = deepcopy(hexas)
                estado = hexa.estado
                matriz_f[destino[0]][destino[1]].estado = estado
                atacar_experto(destino,matriz_f)
                f_evaluadora = -1*valor_funcion(hexas,origen, destino,True)
                maximo_h = maximo_humano(matriz_f)
                if maximo_h != None:
                    maxi = maximo_h['valor']
                else:
                    maxi = 0

                diferencia = maxi + f_evaluadora
                if diferencia<menor:
                    salto = True
                    menor=diferencia
                    hex_destino = destino

    return {'valor':menor,'destino':hex_destino ,'salto':salto}

def jugar_maquina_normal(hexas,pantalla):
    mejor_casilla = None    
    cant_mejor = -1   
     
    for fila in hexas:
        for key, hexa in fila.iteritems():
            if hexa.estado in [4,5,6]:
                maximo_ficha= maximo_valor(hexa,hexas)
                mayor = maximo_ficha['valor']
                if mayor > cant_mejor: 
                    cant_mejor = mayor 
                    mejor_casilla = maximo_ficha
                    mejor_casilla['origen'] = (hexas.index(fila),key)

    origen_x = mejor_casilla['origen'][0]
    origen_y = mejor_casilla['origen'][1]
    destino_x = mejor_casilla['destino'][0]
    destino_y = mejor_casilla['destino'][1]
    hexas[destino_x][destino_y].estado = hexas[origen_x][origen_y].estado
    if not mejor_casilla['salto']:
        aumentar_marcador(hexas[origen_x][origen_y].estado)
    atacar(hexas[destino_x][destino_y],hexas,pantalla) 
    hexas[destino_x][destino_y].dibujar()
    if encerrado(hexas):
        return True
    return False


def jugar_maquina_experto(hexas,pantalla):
    valor = 100
    for fila in hexas:
        for key, hexa in fila.iteritems():
            if hexa.estado in [4,5,6]:
                
                dato = maximo_valor_experto(hexa,hexas)
                if dato['valor'] < valor:
                    valor = dato['valor']
                    minimo = maximo_valor_experto(hexa,hexas)
                    minimo['origen'] = (hexas.index(fila),key)                

    origen_x = minimo['origen'][0]
    origen_y = minimo['origen'][1]
    destino_x = minimo['destino'][0]
    destino_y = minimo['destino'][1]

    hexas[destino_x][destino_y].estado = hexas[origen_x][origen_y].estado
    if minimo['salto']: 
        hexas[origen_x][origen_y].estado = 0
    if not minimo['salto']:
        aumentar_marcador(hexas[origen_x][origen_y].estado)
    atacar(hexas[destino_x][destino_y],hexas,pantalla) 
    hexas[destino_x][destino_y].dibujar()
    if encerrado(hexas):
        return True
    return False


def fichas_ganadas(hexa,estado,hexas):
    ganadas= 0
    for adya in hexa.lista_adya:
        if existe(adya,hexas):
            hexa_adya = hexas[adya[0]][adya[1]]
            if estado == 1:
                if hexa_adya.estado==6:
                    ganadas+=1

            if estado == 2:
                if hexa_adya.estado==4:
                    ganadas+=1
            
            if estado == 3:
                if hexa_adya.estado==5:
                    ganadas+=1

            if estado == 4:
                if hexa_adya.estado==3:
                    ganadas+=1
                    
            if estado == 5:
                if hexa_adya.estado==1:
                    ganadas+=1

            if estado == 6:
                if hexa_adya.estado==2:
                    ganadas+=1

    return ganadas

def valor_funcion(hexas,origen,destino,salto): #origen 8,4 destio 7,5 
    estado = hexas[origen[0]][origen[1]].estado
    ganadas = fichas_ganadas(hexas[destino[0]][destino[1]],estado,hexas)
    if not salto:
        ganadas+=0.7

   
       
    peso = constantes.PESOS[str(origen[0])][origen[1]]
    peso_d = constantes.PESOS[str(destino[0])][destino[1]]
    
    if salto:
        return constantes.FA*ganadas + constantes.FB*(peso_d-peso)
    else:
        return constantes.FA*ganadas + constantes.FB*peso

class Fuente:

    def __init__(self):
        pygame.font.init()
        self.fuente = pygame.font.Font("cubicfive10.ttf", 30)

    def render(self, texto):
        return self.fuente.render(texto, False, BLANCO)


class Hexagono:

    def __init__(self, pantalla, x, y, id, estado_inicial):
        self.pantalla = pantalla
        self.d = LONG
        self.color = BLANCO
        self.marcada = False
        self.id = id
        self.lista_adya = []
        self.lista_salto = []
        self.estado = estado_inicial 
        # coordenadas del centro
        self.x = x
        self.y = y
        self.rect = pygame.Rect(self.x - self.d/2 - 4, self.y - self.d, self.d + 8, self.d*2)

    def crear_lista_adya(self,ind_x,ind_y):
        
        lista_adya = []
        if ind_x<4:
            lista_adya = [(ind_x-1,ind_y),(ind_x+1,ind_y),(ind_x-1,ind_y-1),(ind_x,ind_y-1),(ind_x,ind_y+1),(ind_x+1,ind_y+1)]
        else:
            if ind_x==4:
                lista_adya = [(ind_x-1,ind_y-1),(ind_x,ind_y-1),(ind_x+1,ind_y-1),(ind_x-1,ind_y),(ind_x,ind_y+1),(ind_x+1,ind_y)]
            else:
                lista_adya = [(ind_x-1,ind_y),(ind_x-1,ind_y+1),(ind_x,ind_y-1),(ind_x,ind_y+1),(ind_x+1,ind_y-1),(ind_x+1,ind_y)]

        self.lista_adya=lista_adya

    def crear_lista_salto(self,ind_x,ind_y):
        lista_salto = []
        if ind_x<4:
            lista_salto = [(ind_x-2,ind_y-2),(ind_x-2,ind_y-1),(ind_x-1,ind_y-2),\
                            (ind_x-1,ind_y+1),(ind_x+1,ind_y-1),(ind_x+1,ind_y+2),\
                            (ind_x+2,ind_y+1),(ind_x-2,ind_y),\
                            (ind_x+2,ind_y),(ind_x,ind_y-2),(ind_x,ind_y+2),]
            if ind_x==3:
                lista_salto.append((ind_x+2,ind_y-1))
            else:
                lista_salto.append((ind_x+2,ind_y+2))

        else:
            if ind_x==4:
                lista_salto = [(ind_x-2,ind_y-2),(ind_x-2,ind_y-1),(ind_x-1,ind_y-2),\
                            (ind_x-1,ind_y+1),(ind_x+1,ind_y-2),(ind_x+1,ind_y+1),\
                            (ind_x+2,ind_y-2),(ind_x+2,ind_y-1),(ind_x-2,ind_y),\
                            (ind_x+2,ind_y),(ind_x,ind_y-2),(ind_x,ind_y+2),]
            else:
                lista_salto = [(ind_x-2,ind_y+1),(ind_x-1,ind_y-1),\
                            (ind_x-1,ind_y+2),(ind_x+1,ind_y-2),(ind_x+1,ind_y+1),\
                            (ind_x+2,ind_y-2),(ind_x+2,ind_y-1),(ind_x-2,ind_y),\
                            (ind_x+2,ind_y),(ind_x,ind_y-2),(ind_x,ind_y+2),]
                if ind_x==5:
                    lista_salto.append((ind_x-2,ind_y-1))
                else:
                    lista_salto.append((ind_x-2,ind_y+2))

        self.lista_salto=lista_salto
         

    def dibujar(self):

        pl = [(self.x - self.d, self.y),
              (self.x - self.d/2, self.y - self.d),
              (self.x + self.d/2, self.y - self.d),
              (self.x + self.d, self.y),
              (self.x + self.d/2, self.y + self.d),
              (self.x - self.d/2, self.y + self.d)]
        pygame.draw.polygon(self.pantalla, self.color, pl)
        pygame.draw.polygon(self.pantalla, (100,100,100), pl, 3)
        if self.estado==2:
            self.pantalla.blit(papel_r,(self.x-20,self.y-20))
        if self.estado==4:
            self.pantalla.blit(piedra_a,(self.x-20,self.y-20))
        if self.estado==6:
            self.pantalla.blit(tijera_a,(self.x-20,self.y-20))
        if self.estado==3:
            self.pantalla.blit(tijera_r,(self.x-20,self.y-20))
        if self.estado==1:
            self.pantalla.blit(piedra_r,(self.x-20,self.y-20))
        if self.estado==5:
            self.pantalla.blit(papel_a,(self.x-20,self.y-20))
        
        # pygame.draw.rect(self.pantalla, NEGRO, self.rect)

    def dibujar_adya(self,hexas):
        
        global lista_marc
        global jugador 
        if lista_marc:
            for marc in lista_marc:
                marc.color = BLANCO
                marc.marcada = False 

        lista_marc = []
        for adya in self.lista_adya:
            if existe(adya,hexas):
                if hexas[adya[0]][adya[1]].estado == 0: 
                    lista_marc.append(hexas[adya[0]][adya[1]])
                    if jugador==ROJO:
                        hexas[adya[0]][adya[1]].color = ROJO_C
                    if jugador==AZUL:
                        hexas[adya[0]][adya[1]].color = AZUL_C

                    hexas[adya[0]][adya[1]].dibujar()
                    hexas[adya[0]][adya[1]].marcada = True

        for salto in self.lista_salto:
            if existe(salto,hexas):
                if hexas[salto[0]][salto[1]].estado == 0: 
                    lista_marc.append(hexas[salto[0]][salto[1]])
                    if jugador==ROJO:
                        hexas[salto[0]][salto[1]].color = ROJO_C_SALTO
                    if jugador==AZUL:
                        hexas[salto[0]][salto[1]].color = AZUL_C_SALTO

                    hexas[salto[0]][salto[1]].dibujar()
                    hexas[salto[0]][salto[1]].marcada = True
                   


    def update(self, x, y, p,hexas,pantalla):
        c = self.rect.collidepoint(x, y)
        if c:
            global estado_ficha_s
            global lista_marc
            global ficha_s 
            if p: 
                if estado_ficha_s>0:
                    if self in lista_marc:
                        
                        if ubicacion(self,hexas) in ficha_s.lista_adya:
                            self.estado = estado_ficha_s
                            aumentar_marcador(self.estado)
                        else:
                            self.estado = estado_ficha_s
                            ficha_s.estado = 0 
                        estado_ficha_s=0
                        if atacar(self,hexas,self.pantalla):
                            return 1
                        if MAQUINA:
                            if DIFICULTAD == 1 :
                                if jugar_maquina_normal(hexas,pantalla):
                                    return 1
                            elif DIFICULTAD == 2:
                                if jugar_maquina_experto(hexas,pantalla):
                                    return 1
                            else:    
                                if jugar_maquina(hexas,pantalla):
                                    return 1 
                        else:
                            cambiar_jugador(hexas)
                        dibujar_marcador(self.pantalla)
                        limpiar(hexas)
                    else:
                        if self.estado in [1,2,3] and estado_ficha_s in [1,2,3]:
                            estado_ficha_s = self.estado
                            self.dibujar_adya(hexas) 
                            self.marcar()
                            ficha_s.color = BLANCO
                            ficha_s = self
                        if self.estado in [4,5,6] and estado_ficha_s in [4,5,6]:
                            estado_ficha_s = self.estado
                            self.dibujar_adya(hexas) 
                            self.marcar() 
                            ficha_s.color = BLANCO
                            ficha_s = self
                else: 
                    if self.estado in [1,2,3] and jugador==ROJO:
                        estado_ficha_s = self.estado
                        self.dibujar_adya(hexas) 
                        self.marcar()
                        ficha_s = self
                    if self.estado in [4,5,6] and jugador==AZUL:
                        estado_ficha_s = self.estado
                        self.dibujar_adya(hexas) 
                        self.marcar()
                        ficha_s = self
                return 3
            return 2
        return 0
        
            
        
    def marcar(self):
        
        self.color = jugador
        self.marcada = True

            
    def enfocar(self):
        if not self.marcada:
            self.color = color_jugador_claro
        
    def desenfocar(self):
        if not self.marcada:
            self.color = BLANCO


class Tablero:

    def __init__(self, pantalla):
        self.pantalla = pantalla
        
        self.iniciar()
        
    def iniciar(self):
        estado_inicial = 0 
        self.hexas = []
        self.fila = {}
        self.foco = None
        self.id = 0
        dx = 270
        dy = 150 # largo """ 
        hy = 5 #""" alto"""
        hx = 9 #""" dy + hy -1"""
        # tablero
        au = -1
        for i in range(hx):
            if i < hy :
                au +=1 
            else:
                if i > (hx-hy) :
                    au -= 1
            for e in range(5+au):
                if i < 5:
                    x = dx + LONG*(e + i - au)*1.5
                    y = dy + LONG*(i - e + au)
                else:
                    x = dx + LONG   *(e + i - (hy-1) )*1.5
                    y = dy + LONG*(i - e + (hy-1))
                self.id += 1
                
                self.fila[e] = Hexagono(self.pantalla, x, y, self.id,estado_inicial)
                self.fila[e].crear_lista_adya(i,e)
                self.fila[e].crear_lista_salto(i,e)
            self.hexas.append(self.fila)
            self.fila = {}
        self.hexas[0][0].estado=2
        self.hexas[0][4].estado=4
        self.hexas[4][0].estado=6
        self.hexas[4][8].estado=3
        self.hexas[8][0].estado=1
        self.hexas[8][4].estado=5
            

    

    def dibujar(self):
        x, y = pygame.mouse.get_pos() 
        adyacentes = []     
        click = pygame.event.wait().type == pygame.MOUSEBUTTONDOWN
        gano = None
        for fila in self.hexas:
            for key, h in fila.iteritems(): 
                r = h.update(x, y, click,self.hexas,self.pantalla)
                if r:
                    # marco
                    if r == 1:
                        self.foco = None
                        gano = jugador
                    if r == 3:
                        self.foco = None
                        
                    # enfoco
                    elif r == 2:
                        if self.foco and self.foco != h:
                            self.foco.desenfocar()
                        self.foco = h

                if self.foco:
                    self.foco.enfocar()
            
                h.dibujar()

        
        num_fichas_r = num_pa_r + num_pi_r + num_ti_r       
        num_fichas_a = num_pa_a + num_pi_a + num_ti_a
        num_fichas = num_fichas_a + num_fichas_r  
         
        if num_fichas==61 or (num_fichas_r==0 or num_fichas_a==0):
            if num_fichas_a > num_fichas_r: 
                gano = AZUL
            else:
                gano = ROJO       
                
        
        return gano
            
    def resolver(self, y,x):
        vistos = []
        color = self.hexas[y][x].color
        ##cadena = [h for h in self.alrededor(id, color, vistos)]
        ##if self.principio(cadena, color) and self.fin(cadena, color):
        #return color
        return None
        
    

    def principio(self, cadena, color):
        if color == AZUL:
            for c in cadena:
                if self.hexas[c].azul_p:
                    return True
        else:
            for c in cadena:
                if self.hexas[c].ROJO_p:
                    return True            
        return False
    
    def fin(self, cadena, color):
        if color == AZUL:
            for c in cadena:
                if self.hexas[c].azul_f:
                    return True
        else:
            for c in cadena:
                if self.hexas[c].ROJO_f:
                    return True            
        return False
    

class Pantalla:

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Hex")
        
        # os.environ["SDL_VIDEO_CENTERED"] = "1"
        self.pantalla = pygame.display.set_mode((LONG*40, LONG*15*2))
        self.t = Tablero(self.pantalla)
        self.gano = True
        self.color = None
        self.fuente = Fuente()
        self.main()        

    def main(self):
        global RUN
        while RUN:

            self.pantalla.fill(NEGRO)
            # mostramos            
            pygame.event.pump()
            if not self.gano:
                color = self.t.dibujar()
                dibujar_marcador(self.pantalla)

                if color:
                    self.gano = True
                    self.color = color
                
            else:
                self.ganador()
            pygame.display.update()
            if not self.update():
                RUN = False
                break
            

            
        pygame.quit()
        
    def ganador(self):
        if self.color == AZUL:
            color = "Azul"
        else:
            color = "ROJO"

        if self.color:
            r1 = self.fuente.render("Gano el jugador " + color)
        n = self.fuente.render("ELIJA UNA OPCION:")
        r = self.fuente.render("[1] H vs H")
        r2 = self.fuente.render("[2] H VS C (random)")
        r3 = self.fuente.render("[3] H VS C (normal)")
        r4 = self.fuente.render("[4] H VS C (experto)")
        r5 = self.fuente.render("[Esc] Salir")
        r6 = self.fuente.render("INTELIGENCIA ARTIFICIAL 2014 - I ")
        
        if self.color:
            self.pantalla.blit(r1, (200,25))
        self.pantalla.blit(n, (200,100))
        self.pantalla.blit(r, (200,200))
        self.pantalla.blit(r2, (200,250))
        self.pantalla.blit(r3, (200,300))
        self.pantalla.blit(r4, (200,350))
        self.pantalla.blit(r5, (200,400))
        self.pantalla.blit(r6, (370,410))

    def update(self):
        global MAQUINA
        global DIFICULTAD
        k = pygame.key.get_pressed()
        if k[pygame.K_ESCAPE]:
            return False
        else:
            if k[pygame.K_1]:
                self.gano = False
                iniciar()
                self.t.iniciar()
                MAQUINA = False
            if k[pygame.K_2]:
                self.gano = False
                iniciar()
                self.t.iniciar()
                MAQUINA = True
                DIFICULTAD = 0
            if k[pygame.K_3]:
                self.gano = False
                iniciar()
                self.t.iniciar()
                MAQUINA = True
                DIFICULTAD = 1
            if k[pygame.K_4]:
                self.gano = False
                iniciar()
                self.t.iniciar()
                MAQUINA = True
                DIFICULTAD = 2

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False
        return True

Pantalla()
